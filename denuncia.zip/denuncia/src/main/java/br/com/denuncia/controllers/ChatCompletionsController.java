package br.com.denuncia.controllers;

import br.com.denuncia.dto.ChatCompletionRequestDTO;
import br.com.denuncia.dto.ChatCompletionResponseDTO;
import br.com.denuncia.dto.MessageDTO;
import br.com.denuncia.model.OpenApiClient;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatCompletionsController {

    @Value("${openai.model}")
    private String model;

    @Autowired
    private OpenApiClient openApiClient;

    @PostMapping("/ask")
    public String askQuestion(@RequestBody String question) {
        ChatCompletionRequestDTO requestDTO = new ChatCompletionRequestDTO();
        requestDTO.setModel(model);

        MessageDTO messageSystem = new MessageDTO();
        messageSystem.setRole("system");
        messageSystem.setContent("Você é um assistente para atendimentos de disque denúncia (Homicídio e furto)");

        MessageDTO messageUser = new MessageDTO();
        messageUser.setRole("user");
        messageUser.setContent(question);

        requestDTO.setMessages(List.of(messageSystem, messageUser));

        ResponseEntity<String> response = openApiClient.getChatCompletionResponse(requestDTO);
        ChatCompletionResponseDTO chatCompletionResponseDTO = new Gson().fromJson(response.getBody(), ChatCompletionResponseDTO.class);

        System.out.println("-------------------------------------");
        System.out.println(chatCompletionResponseDTO);
        System.out.println("-------------------------------------");

        return chatCompletionResponseDTO
                .getChoices()
                .get(0)
                .getMessage()
                .getContent();
    }
}
