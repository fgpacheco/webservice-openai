package br.com.denuncia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DenuncIaApplicationTests {

	@Test
	void contextLoads() {
	}

}
